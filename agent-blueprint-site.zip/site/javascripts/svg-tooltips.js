document.addEventListener("DOMContentLoaded", function () {
  const tip = document.createElement("div");
  tip.id = "svg-tooltip";
  document.body.appendChild(tip);

  document.addEventListener("mouseover", function (e) {
    const g = e.target.closest("g[title]");
    if (!g) return;
    tip.textContent = g.getAttribute("title");
    tip.classList.add("visible");
  });

  document.addEventListener("mousemove", function (e) {
    if (!tip.classList.contains("visible")) return;
    const x = e.clientX + 16;
    const y = e.clientY + 16;
    // Keep tooltip within viewport horizontally
    const overflow = x + tip.offsetWidth - window.innerWidth;
    tip.style.left = (overflow > 0 ? e.clientX - tip.offsetWidth - 8 : x) + "px";
    tip.style.top = y + "px";
  });

  // Hide only when leaving the <g> entirely (not when moving between its children)
  document.addEventListener("mouseout", function (e) {
    const g = e.target.closest("g[title]");
    if (!g) return;
    if (!g.contains(e.relatedTarget)) {
      tip.classList.remove("visible");
    }
  });
});
